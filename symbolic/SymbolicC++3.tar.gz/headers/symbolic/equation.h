/*
    SymbolicC++ : An object oriented computer algebra system written in C++

    Copyright (C) 2008 Yorick Hardy and Willi-Hans Steeb

    This library is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/


// equation.h

#ifndef SYMBOLIC_CPLUSPLUS_EQUATION

using namespace std;

#ifdef  SYMBOLIC_FORWARD
#ifndef SYMBOLIC_CPLUSPLUS_EQUATION_FORWARD
#define SYMBOLIC_CPLUSPLUS_EQUATION_FORWARD

class Equation;

#endif
#endif

#ifdef  SYMBOLIC_DECLARE
#ifndef SYMBOLIC_CPLUSPLUS_EQUATION_DECLARE
#define SYMBOLIC_CPLUSPLUS_EQUATION_DECLARE

class Equation: public CloningSymbolicInterface
{
 public: Symbolic lhs, rhs;
         Equation(const Equation&);
         Equation(const Symbolic&,const Symbolic&);
         ~Equation();

         void print(ostream&) const;
         Symbolic subst(const Symbolic&,const Symbolic&,int &n) const;
         Simplified simplify() const;
         int compare(const Symbolic&) const;
         Symbolic df(const Symbolic&) const;
         Symbolic integrate(const Symbolic&) const;
         Symbolic coeff(const Symbolic&) const;
         Expanded expand() const;
         int commute(const Symbolic&) const;

         operator bool() const;
         operator int() const;

         Cloning *clone() const { return Cloning::clone(*this); }
};

#endif
#endif

#ifdef  SYMBOLIC_DEFINE
#ifndef SYMBOLIC_CPLUSPLUS_EQUATION_DEFINE
#define SYMBOLIC_CPLUSPLUS_EQUATION_DEFINE
#define SYMBOLIC_CPLUSPLUS_EQUATION

Equation::Equation(const Equation &s)
: CloningSymbolicInterface(s), lhs(s.lhs), rhs(s.rhs) {}

Equation::Equation(const Symbolic &s1,const Symbolic &s2)
: lhs(s1), rhs(s2) {}

Equation::~Equation() {}

void Equation::print(ostream &o) const
{ o << lhs << " == " << rhs; }

Symbolic Equation::subst(const Symbolic &x,const Symbolic &y,int &n) const
{ return Equation(lhs.subst(x,y,n),rhs.subst(x,y,n)); }

Simplified Equation::simplify() const
{ return Equation(lhs.simplify(),rhs.simplify()); }

int Equation::compare(const Symbolic &s) const
{
 if(s.type() != type()) return 0;

 CastPtr<const Equation> e = s;
 return (lhs.compare(e->lhs) && rhs.compare(e->rhs)) ||
        (lhs.compare(e->rhs) && rhs.compare(e->lhs));
}

Symbolic Equation::df(const Symbolic &s) const
{ return Equation(lhs.df(s),rhs.df(s)); }

Symbolic Equation::integrate(const Symbolic &s) const
{ return Equation(lhs.integrate(s),rhs.integrate(s)); }

Symbolic Equation::coeff(const Symbolic &s) const
{ return 0; }

Expanded Equation::expand() const
{ return Equation(lhs.expand(),rhs.expand()); }

int Equation::commute(const Symbolic &s) const
{ return 0; }

Equation::operator bool() const
{ return lhs.compare(rhs); }

Equation::operator int() const
{ return lhs.compare(rhs); }

#endif
#endif
#endif
